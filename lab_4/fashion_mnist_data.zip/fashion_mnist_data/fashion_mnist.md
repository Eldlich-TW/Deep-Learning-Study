fashion_mnist.pickle
该打包文件存放的是处理好的fashion_mnist 数据集， 使用方式如下：
```
import pickle 
f = open('fashion_mnist.pickle', 'rb')
train, test = pickle.load(f)
f.close()
等价于：

from tensorflow.keras.datasets import fashion_mnist
train, test = fashion_mnist.load_data()
```