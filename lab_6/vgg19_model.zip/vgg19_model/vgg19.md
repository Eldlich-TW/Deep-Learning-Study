## vgg19_weights_tf_dim_ordering_tf_kernels_notop.h5
该数据为在imagenet 数据集上训练好的 vgg19 模型， 使用方式如下：
```
import tensorflow
model = tensorflow.keras.applications.vgg19.VGG19(include_top=False,weights=None)
model.load_weights('./vgg19_weights_tf_dim_ordering_tf_kernels_notop.h5')
```
等价于：
```
import tensorflow
model = tensorflow.keras.applications.vgg19.VGG19(include_top=False,weights='imagenet')
```